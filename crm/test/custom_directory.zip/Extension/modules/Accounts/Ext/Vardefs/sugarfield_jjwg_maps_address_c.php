<?php
 // created: 2019-02-21 11:18:45
$dictionary['Account']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>