<?php
 // created: 2019-02-21 11:18:44
$dictionary['Account']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>