<?php
 // created: 2019-02-21 11:18:47
$dictionary['Project']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>