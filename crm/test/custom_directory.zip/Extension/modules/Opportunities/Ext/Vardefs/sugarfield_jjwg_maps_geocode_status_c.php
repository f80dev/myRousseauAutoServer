<?php
 // created: 2019-02-21 11:18:47
$dictionary['Opportunity']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>