<?php
 // created: 2019-02-21 11:18:45
$dictionary['Case']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>