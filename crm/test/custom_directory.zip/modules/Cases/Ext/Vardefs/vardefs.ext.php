<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2019-02-21 11:18:45
$dictionary['Case']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 

 // created: 2019-02-21 11:18:45
$dictionary['Case']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 

 // created: 2019-02-21 11:18:45
$dictionary['Case']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2019-02-21 11:18:45
$dictionary['Case']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 
?>